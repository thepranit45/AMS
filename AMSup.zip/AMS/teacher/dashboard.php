<?php
session_start();
// Check if the teacher is logged in
if (!isset($_SESSION['teacher_id'])) {
    header("Location: /AMS/common/login.php");
    exit();
}
require '../common/header.php';
require '../common/db_connection.php';

// Fetch total students
$stmt = $conn->query("SELECT COUNT(*) AS total_students FROM student");
$total_students = $stmt->fetch()['total_students'];

// Fetch today's attendance
$today = date('Y-m-d');
$stmt = $conn->prepare("SELECT COUNT(*) AS total_attendance FROM attendance WHERE date = ? AND teacher_id = ?");
$stmt->execute([$today, $_SESSION['teacher_id']]);
$total_attendance = $stmt->fetch()['total_attendance'];

// Fetch monthly attendance data
$stmt = $conn->prepare("
    SELECT 
        TO_CHAR(date, 'Month') AS month, 
        COUNT(*) AS attendance_count 
    FROM attendance 
    WHERE teacher_id = ? 
    GROUP BY TO_CHAR(date, 'Month'), EXTRACT(MONTH FROM date) 
    ORDER BY EXTRACT(MONTH FROM date)
");
$stmt->execute([$_SESSION['teacher_id']]);
$attendance_data = $stmt->fetchAll();

// Prepare data for Chart.js
$months = [];
$attendance_counts = [];
foreach ($attendance_data as $row) {
    $months[] = trim($row['month']); // Trim to remove extra spaces
    $attendance_counts[] = $row['attendance_count'];
}
?>

<h1 class="mb-4">Teacher Dashboard</h1>
<div class="row">
    <!-- Total Students Card -->
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-header">Total Students</div>
            <div class="card-body">
                <h5 class="card-title"><?= $total_students ?></h5>
                <p class="card-text">Number of students in your class.</p>
            </div>
        </div>
    </div>

    <!-- Today's Attendance Card -->
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
            <div class="card-header">Today's Attendance</div>
            <div class="card-body">
                <h5 class="card-title"><?= $total_attendance ?></h5>
                <p class="card-text">Students attended today.</p>
            </div>
        </div>
    </div>

    <!-- Quick Links Card -->
    <div class="col-md-4">
        <div class="card text-white bg-info mb-3">
            <div class="card-header">Quick Links</div>
            <div class="card-body">
                <ul class="list-unstyled">
                    <li><a href="view_students.php" class="text-white">View Students</a></li>
                    <li><a href="mark_attendance.php" class="text-white">Mark Attendance</a></li>
                    <li><a href="view_attendance.php" class="text-white">View Attendance</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Monthly Attendance Graph -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                Monthly Attendance Report
            </div>
            <div class="card-body">
                <canvas id="attendanceChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Data for the chart
    const months = <?= json_encode($months) ?>;
    const attendanceCounts = <?= json_encode($attendance_counts) ?>;

    // Create the bar chart
    const ctx = document.getElementById('attendanceChart').getContext('2d');
    const attendanceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: months,
            datasets: [{
                label: 'Number of Attendances',
                data: attendanceCounts,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Attendances'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Month'
                    }
                }
            }
        }
    });
</script>

<?php require '../common/footer.php'; ?>