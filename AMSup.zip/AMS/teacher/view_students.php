<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: /common/login.php");
    exit();
}
require '../common/header.php';
require '../common/db_connection.php';

// Fetch all students
$stmt = $conn->query("SELECT * FROM student");
$students = $stmt->fetchAll();
?>

<h1>View Students</h1>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Roll Number</th>
            <th>Class</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($students as $student): ?>
        <tr>
            <td><?= $student['student_id'] ?></td>
            <td><?= $student['name'] ?></td>
            <td><?= $student['roll_number'] ?></td>
            <td><?= $student['class'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require '../common/footer.php'; ?>