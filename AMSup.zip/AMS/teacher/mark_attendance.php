<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: /common/login.php");
    exit();
}
require '../common/header.php';
require '../common/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $status = $_POST['status'];
    $date = date('Y-m-d');

    $stmt = $conn->prepare("INSERT INTO attendance (student_id, teacher_id, date, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$student_id, $_SESSION['teacher_id'], $date, $status]);
    echo "<div class='alert alert-success'>Attendance marked successfully!</div>";
}

// Fetch all students
$stmt = $conn->query("SELECT * FROM student");
$students = $stmt->fetchAll();
?>

<h1 class="mb-4">Mark Attendance</h1>
<div class="card">
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label for="student_id" class="form-label">Student</label>
                <select class="form-select" id="student_id" name="student_id" required>
                    <?php foreach ($students as $student): ?>
                    <option value="<?= $student['student_id'] ?>"><?= $student['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="Present">Present</option>
                    <option value="Absent">Absent</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Mark Attendance</button>
        </form>
    </div>
</div>

<?php require '../common/footer.php'; ?>