<?php
// functions.php file content
?>