<?php
session_start();
session_destroy();
header("Location: /AMS/common/login.php");
exit();
?>