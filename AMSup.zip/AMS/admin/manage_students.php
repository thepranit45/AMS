<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: /common/login.php");
    exit();
}
require '../common/aheader.php';
require '../common/db_connection.php';

// Fetch all students
$stmt = $conn->query("SELECT * FROM student");
$students = $stmt->fetchAll();
?>

<h1 class="mb-4">Manage Students</h1>
<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Roll Number</th>
                    <th>Class</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                <tr>
                    <td><?= $student['student_id'] ?></td>
                    <td><?= $student['name'] ?></td>
                    <td><?= $student['roll_number'] ?></td>
                    <td><?= $student['class'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../common/footer.php'; ?>