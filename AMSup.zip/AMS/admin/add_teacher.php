<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: /AMS/common/login.php");
    exit();
}

require '../common/aheader.php';
require '../common/db_connection.php';

// Ensure database connection is established
if (!isset($conn) || !$conn) {
    die("Database connection not established.");
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validate input length
    if (strlen($name) > 100) {
        $error = "Name must be 100 characters or less.";
    } elseif (strlen($username) > 50) {
        $error = "Username must be 50 characters or less.";
    } elseif (strlen($password) > 50) {
        $error = "Password must be 50 characters or less.";
    } elseif (empty($name) || empty($username) || empty($password)) {
        $error = "All fields are required!";
    } else {
        try {
            // Check if username already exists
            $query = "SELECT * FROM teacher WHERE username = :username";
            $stmt = $conn->prepare($query);
            $stmt->execute(['username' => $username]);

            if ($stmt->rowCount() > 0) {
                $error = "Username already taken!";
            } else {
                // Insert new teacher with hashed password
                $insertQuery = "INSERT INTO teacher (name, username, password) VALUES (:name, :username, :password)";
                $insertStmt = $conn->prepare($insertQuery);
                $insertStmt->execute([
                    'name' => $name,
                    'username' => $username,
                    'password' => password_hash($password, PASSWORD_BCRYPT) // Hashed password
                ]);
                $success = "Teacher added successfully!";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<h1 class="mb-4">Add Teacher</h1>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<form method="post">
    <div class="mb-3">
        <label for="name" class="form-label">Name:</label>
        <input type="text" name="name" id="name" class="form-control" required maxlength="100">
    </div>
    <div class="mb-3">
        <label for="username" class="form-label">Username:</label>
        <input type="text" name="username" id="username" class="form-control" required maxlength="50">
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password:</label>
        <input type="password" name="password" id="password" class="form-control" required maxlength="50">
    </div>
    <button type="submit" class="btn btn-primary">Add Teacher</button>
</form>

<?php require '../common/footer.php'; ?>
