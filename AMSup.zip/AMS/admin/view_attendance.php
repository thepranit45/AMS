<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: /common/login.php");
    exit();
}
require '../common/aheader.php';
require '../common/db_connection.php';

// Fetch all attendance records
$stmt = $conn->query("SELECT a.*, s.name AS student_name, t.name AS teacher_name 
                      FROM attendance a 
                      JOIN student s ON a.student_id = s.student_id 
                      JOIN teacher t ON a.teacher_id = t.teacher_id");
$attendance = $stmt->fetchAll();
?>

<h1 class="mb-4">View Attendance</h1>
<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Teacher</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendance as $record): ?>
                <tr>
                    <td><?= $record['student_name'] ?></td>
                    <td><?= $record['teacher_name'] ?></td>
                    <td><?= $record['date'] ?></td>
                    <td><?= $record['status'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../common/footer.php'; ?>