<?php
session_start();
// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: /AMS/common/login.php");
    exit();
}

require '../common/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher_id = $_POST['teacher_id'];

    // Prepare and execute the delete query
    $stmt = $conn->prepare("DELETE FROM teacher WHERE teacher_id = :teacher_id");
    $stmt->bindParam(':teacher_id', $teacher_id);
    $stmt->execute();

    // Redirect back to the manage teachers page
    header("Location: manage_teachers.php");
    exit();
}