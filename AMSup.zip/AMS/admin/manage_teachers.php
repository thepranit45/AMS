<?php
session_start();
// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: /AMS/common/login.php");
    exit();
}
require '../common/aheader.php';
require '../common/db_connection.php';

// Fetch all teachers
$stmt = $conn->query("SELECT * FROM teacher");
$teachers = $stmt->fetchAll();
?>

<h1 class="mb-4">Manage Teachers</h1>
<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Action</th> <!-- New column for the delete button -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($teachers as $teacher): ?>
                <tr>
                    <td><?= $teacher['teacher_id'] ?></td>
                    <td><?= $teacher['name'] ?></td>
                    <td><?= $teacher['username'] ?></td>
                    <td>
                        <!-- Form to handle deletion -->
                        <form action="delete_teacher.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this teacher?');">
                            <input type="hidden" name="teacher_id" value="<?= $teacher['teacher_id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../common/footer.php'; ?>