<?php
session_start();
require '../common/aheader.php';
require '../common/db_connection.php';



try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submission
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $roll_number = trim($_POST["roll_number"]);
    $class = trim($_POST["class"]);

    if (!empty($name) && !empty($roll_number) && !empty($class)) {
        try {
            $sql = "INSERT INTO student (name, roll_number, class) VALUES (:name, :roll_number, :class)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ":name" => $name,
                ":roll_number" => $roll_number,
                ":class" => $class
            ]);
            $message = "Student added successfully!";
        } catch (PDOException $e) {
            $message = "Error: " . $e->getMessage();
        }
    } else {
        $message = "All fields are required!";
    }
}
?>

<div class="container mt-4">
    <h2>Add Student</h2>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="name">Student Name</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="roll_number">Roll Number</label>
            <input type="text" name="roll_number" id="roll_number" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="class">Class</label>
            <input type="text" name="class" id="class" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Student</button>
    </form>
</div>

<?php require '../common/footer.php'; ?>
