<?php
session_start();
// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: /AMS/common/login.php");
    exit();
}
require '../common/aheader.php';
?>

<h1 class="mb-4">Admin Dashboard</h1>
<div class="row">
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-header">Manage Students</div>
            <div class="card-body">
                <p class="card-text">Add, update, or delete student records.</p>
                <a href="/AMS/admin/manage_students.php" class="btn btn-light">Go to Manage Students</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
            <div class="card-header">Manage Teachers</div>
            <div class="card-body">
                <p class="card-text">Add, update, or delete teacher records.</p>
                <a href="/AMS/admin/manage_teachers.php" class="btn btn-light">Go to Manage Teachers</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info mb-3">
            <div class="card-header">View Attendance</div>
            <div class="card-body">
                <p class="card-text">View attendance records for students.</p>
                <a href="/AMS/admin/view_attendance.php" class="btn btn-light">Go to View Attendance</a>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>